﻿using System;
using System.Windows.Forms;
using System.IO;
using System.Threading.Tasks;
using System.Text;

namespace Library
{
    public partial class AboutProgram : Form
    {
        string pathToFile = "log.txt";
        public AboutProgram()
        {
            InitializeComponent();
        }
        private static async Task AppendLineToFile(string path, string line)
        {
            if (string.IsNullOrWhiteSpace(path)) //проверяем, что имя файла не пустое
                throw new ArgumentOutOfRangeException(nameof(path), path, "Was null or whitespace.");

            if (!File.Exists(path))
                throw new FileNotFoundException("File not found.", nameof(path));

            using (var file = File.Open(path, FileMode.Append, FileAccess.Write))
            using (var writer = new StreamWriter(file))
            {
                await writer.WriteLineAsync(line);
                await writer.FlushAsync();// Асинхронно очищает все буферы
            }
        }
        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Encoding.GetEncoding("UTF-8");
            AppendLineToFile(pathToFile, DateTime.Now + " Нажата кнопка закрыть");
            Close();
        }

        private void AboutProgram_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "dataDataSet11.Table". При необходимости она может быть перемещена или удалена.
            // TODO: данная строка кода позволяет загрузить данные в таблицу "dataDataSet.Table". При необходимости она может быть перемещена или удалена.

        }
    }
}
