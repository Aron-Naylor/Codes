﻿namespace Library
{
    partial class Zachet
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Zachet));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.optionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.userADDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.userIDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.refrashToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.otherToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tableBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.Exit = new System.Windows.Forms.Button();
            this.tableBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tableBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.optionsToolStripMenuItem,
            this.otherToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(514, 24);
            this.menuStrip1.TabIndex = 8;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // optionsToolStripMenuItem
            // 
            this.optionsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.userADDToolStripMenuItem,
            this.userIDToolStripMenuItem,
            this.refrashToolStripMenuItem});
            this.optionsToolStripMenuItem.Name = "optionsToolStripMenuItem";
            this.optionsToolStripMenuItem.Size = new System.Drawing.Size(66, 20);
            this.optionsToolStripMenuItem.Text = "Режимы";
            this.optionsToolStripMenuItem.Click += new System.EventHandler(this.optionsToolStripMenuItem_Click);
            // 
            // userADDToolStripMenuItem
            // 
            this.userADDToolStripMenuItem.Name = "userADDToolStripMenuItem";
            this.userADDToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.userADDToolStripMenuItem.Text = "Добавить резюме";
            this.userADDToolStripMenuItem.Click += new System.EventHandler(this.userADDToolStripMenuItem_Click);
            // 
            // userIDToolStripMenuItem
            // 
            this.userIDToolStripMenuItem.Name = "userIDToolStripMenuItem";
            this.userIDToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.userIDToolStripMenuItem.Text = "Поиск по ID";
            this.userIDToolStripMenuItem.Click += new System.EventHandler(this.userIDToolStripMenuItem_Click);
            // 
            // refrashToolStripMenuItem
            // 
            this.refrashToolStripMenuItem.Name = "refrashToolStripMenuItem";
            this.refrashToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.refrashToolStripMenuItem.Text = "Обновить таблицу";
            this.refrashToolStripMenuItem.Click += new System.EventHandler(this.refrashToolStripMenuItem_Click);
            // 
            // otherToolStripMenuItem
            // 
            this.otherToolStripMenuItem.Name = "otherToolStripMenuItem";
            this.otherToolStripMenuItem.Size = new System.Drawing.Size(94, 20);
            this.otherToolStripMenuItem.Text = "О программе";
            this.otherToolStripMenuItem.Click += new System.EventHandler(this.otherToolStripMenuItem_Click);
            // 
            // dataDataSet
            // 
            // 
            // tableBindingSource
            // 
            this.tableBindingSource.DataMember = "Table";
            // 
            // tableTableAdapter
            // 
            // 
            // Exit
            // 
            this.Exit.Location = new System.Drawing.Point(428, 292);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(75, 23);
            this.Exit.TabIndex = 10;
            this.Exit.Text = "Выход";
            this.Exit.UseVisualStyleBackColor = true;
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // tableBindingSource1
            // 
            this.tableBindingSource1.DataMember = "Table";
            // 
            // dataDataSet1
            // 
            // 
            // tableTableAdapter1
            // 
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(12, 27);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(413, 264);
            this.listBox1.TabIndex = 11;
            // 
            // Zachet
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(514, 320);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.Exit);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(530, 359);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(530, 359);
            this.Name = "Zachet";
            this.Text = "Info";
            this.Load += new System.EventHandler(this.Zachet_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tableBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableBindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem optionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem userADDToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem userIDToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem otherToolStripMenuItem;
        private System.Windows.Forms.BindingSource tableBindingSource;
        private System.Windows.Forms.Button Exit;
        private System.Windows.Forms.ToolStripMenuItem refrashToolStripMenuItem;
        private System.Windows.Forms.DataGridViewTextBoxColumn yearOfBirthDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource tableBindingSource1;
        private System.Windows.Forms.ListBox listBox1;
    }
}