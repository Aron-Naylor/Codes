﻿using System;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using System.Threading.Tasks;
using System.Text;

namespace Library
{
    public partial class IDselect : Form
    {
        string pathToFile = "log.txt";
        SqlConnection sqlConnection;
        public IDselect()
        {
            InitializeComponent();
        }

        private static async Task AppendLineToFile(string path, string line)
        {
            if (string.IsNullOrWhiteSpace(path)) //проверяем, что имя файла не пустое
                throw new ArgumentOutOfRangeException(nameof(path), path, "Was null or whitespace.");

            if (!File.Exists(path))
                throw new FileNotFoundException("File not found.", nameof(path));

            using (var file = File.Open(path, FileMode.Append, FileAccess.Write))
            using (var writer = new StreamWriter(file))
            {
                await writer.WriteLineAsync(line);
                await writer.FlushAsync();// Асинхронно очищает все буферы
            }
        }

        private async void FindButton_Click(object sender, EventArgs e)
        {
            Encoding.GetEncoding("UTF-8");
            AppendLineToFile(pathToFile, DateTime.Now + " Поиск по ID");
            listBox2.Items.Clear();
            listBox1.Items.Clear();
            string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename='|DataDirectory|Data.mdf';Integrated Security=True";
            sqlConnection = new SqlConnection(connectionString);

            await sqlConnection.OpenAsync();

            SqlDataReader sqlReader = null;
            SqlCommand command = new SqlCommand("SELECT * FROM [Table] WHERE [Id] LIKE @Id", sqlConnection);//Комманда отбора данных
            command.Parameters.AddWithValue("Id", ID_textBox.Text);

            try
            {
                sqlReader = await command.ExecuteReaderAsync();

                if (!string.IsNullOrEmpty(ID_textBox.Text) && !string.IsNullOrWhiteSpace(ID_textBox.Text))
                {
                    while (await sqlReader.ReadAsync())
                    {//Вывод отобранных данных
                        listBox1.Items.Add(Convert.ToString(sqlReader["id"]) + "     " + Convert.ToString(sqlReader["FIo"]) + "    " + Convert.ToString(sqlReader["Yearofbirth"]) + "    " + Convert.ToString(sqlReader["Number"]));
                        listBox2.Items.Add(Convert.ToString(sqlReader["Work"]));
                    }
                }
                else
                {
                    label3.Visible = true;//Строка ошибки ON
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), ex.Source.ToString(), MessageBoxButtons.OK, MessageBoxIcon.Error);//Вывод ошибки
            }
            finally
            {
                if (sqlReader != null)
                {
                    sqlReader.Close();
                }
            }
        
        }
    }
}
