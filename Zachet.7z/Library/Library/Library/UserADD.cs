﻿using System;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using System.Threading.Tasks;
using System.Text;

namespace Library
{
    public partial class UserADD : Form
    {
        
        string pathToFile = "log.txt";
        SqlConnection sqlConnection;
        public UserADD()
        {
            Encoding.GetEncoding("UTF-8");
            AppendLineToFile(pathToFile, DateTime.Now + " Открыта формаа долбавления записи");
            InitializeComponent();

        }
        private static async Task AppendLineToFile(string path, string line)
        {
            if (string.IsNullOrWhiteSpace(path)) //проверяем, что имя файла не пустое
                throw new ArgumentOutOfRangeException(nameof(path), path, "Was null or whitespace.");

            if (!File.Exists(path))
                throw new FileNotFoundException("File not found.", nameof(path));

            using (var file = File.Open(path, FileMode.Append, FileAccess.Write))
            using (var writer = new StreamWriter(file))
            {
                await writer.WriteLineAsync(line);
                await writer.FlushAsync();// Асинхронно очищает все буферы
            }
        }
        private async void Add_Buttom_Click(object sender, EventArgs e)
        {
            Encoding.GetEncoding("UTF-8");
            AppendLineToFile(pathToFile, DateTime.Now + " Попытка добавить запись");
            if (ErrorLableAdd.Visible)
                ErrorLableAdd.Visible = false;
            if (!string.IsNullOrEmpty(FIO_TEXT.Text) && !string.IsNullOrWhiteSpace(FIO_TEXT.Text) &&
                !string.IsNullOrEmpty(YearOfBitrhTEXT.Text) && !string.IsNullOrWhiteSpace(YearOfBitrhTEXT.Text)&&
                !string.IsNullOrEmpty(TelText.Text) && !string.IsNullOrWhiteSpace(TelText.Text)&&
                !string.IsNullOrEmpty(Work_txt.Text) && !string.IsNullOrWhiteSpace(Work_txt.Text))
            {
                SqlCommand command = new SqlCommand("INSERT INTO [Table](FIo,Yearofbirth,Number,Work)VALUES(@FIo,@Yearofbirth,@Number,@Work)", sqlConnection);

                command.Parameters.AddWithValue("FIo", FIO_TEXT.Text);
                command.Parameters.AddWithValue("Yearofbirth", YearOfBitrhTEXT.Text);
                command.Parameters.AddWithValue("Number", TelText.Text);
                command.Parameters.AddWithValue("Work", Work_txt.Text);
                await command.ExecuteNonQueryAsync();
            }
            else
            {
               ErrorLableAdd.Visible = true;
            }
         }

        private void Add_exit_Click(object sender, EventArgs e)
        {
            Encoding.GetEncoding("UTF-8");
            AppendLineToFile(pathToFile, DateTime.Now + " Форма добавки записи закрыта");
            Close();
        }

        private async void UserADD_Load(object sender, EventArgs e)
        {
            string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename='|DataDirectory|Data.mdf';Integrated Security=True";
            sqlConnection = new SqlConnection(connectionString);
             await sqlConnection.OpenAsync();
          }
    }
}
