﻿using System;
using System.Windows.Forms;
using System.IO;
using System.Threading.Tasks;
using System.Text;
using System.Data.SqlClient;

namespace Library
{
    public partial class Zachet : Form
    {
        SqlConnection sqlConnection;
        string pathToFile = "log.txt";
        public Zachet()
        {
            Encoding.GetEncoding("UTF-8");
            AppendLineToFile(pathToFile, DateTime.Now + " Программа открыта");

            InitializeComponent();
        }
        private static async Task AppendLineToFile(string path, string line)
        {
            if (string.IsNullOrWhiteSpace(path)) //проверяем, что имя файла не пустое
                throw new ArgumentOutOfRangeException(nameof(path), path, "Was null or whitespace.");

            if (!File.Exists(path))
                throw new FileNotFoundException("File not found.", nameof(path));

            using (var file = File.Open(path, FileMode.Append, FileAccess.Write))
            using (var writer = new StreamWriter(file))
            {
                await writer.WriteLineAsync(line);
                await writer.FlushAsync();// Асинхронно очищает все буферы
            }
        }

        private void otherToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Encoding.GetEncoding("UTF-8");
            AppendLineToFile(pathToFile, DateTime.Now + " Открыто о программе");
            AboutProgram Form = new AboutProgram();
            Form.ShowDialog();
        }

        private void optionsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Encoding.GetEncoding("UTF-8");
            AppendLineToFile(pathToFile, DateTime.Now + " Открыта вкладка Режимы");
        }

        private async void Zachet_Load(object sender, EventArgs e)
        {
            string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename='|DataDirectory|Data.mdf';Integrated Security=True";
            sqlConnection = new SqlConnection(connectionString);

            await sqlConnection.OpenAsync();//By Aron Naylor

            SqlDataReader sqlReader = null;
            SqlCommand command = new SqlCommand("SELECT * FROM [Table]", sqlConnection);
            try
            {
                sqlReader = await command.ExecuteReaderAsync();

                while (await sqlReader.ReadAsync())
                {
                    listBox1.Items.Add(Convert.ToString(sqlReader["id"]) + "     " + Convert.ToString(sqlReader["FIo"]) + "    " + Convert.ToString(sqlReader["Yearofbirth"]) + "    " + Convert.ToString(sqlReader["Number"]));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), ex.Source.ToString(), MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (sqlReader != null)
                {
                    sqlReader.Close();
                }
            }

        }

        private void Exit_Click(object sender, EventArgs e)
        {
            Encoding.GetEncoding("UTF-8");
            AppendLineToFile(pathToFile, DateTime.Now + " Программа закрыта");
            Close();
        }

        private void userADDToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Encoding.GetEncoding("UTF-8");
            AppendLineToFile(pathToFile, DateTime.Now + " Выбран режим добавить резюме");
            UserADD Form = new UserADD();
            Form.ShowDialog();

        }

        private void userIDToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Encoding.GetEncoding("UTF-8");
            AppendLineToFile(pathToFile, DateTime.Now + " Выбран режим поиска по ID");
            IDselect Form = new IDselect();
            Form.ShowDialog();
        }

        private async void refrashToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Encoding.GetEncoding("UTF-8");
            AppendLineToFile(pathToFile, DateTime.Now + " Таблица обновлена");
            listBox1.Items.Clear();
            string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename='|DataDirectory|Data.mdf';Integrated Security=True";
            sqlConnection = new SqlConnection(connectionString);

            await sqlConnection.OpenAsync();

            SqlDataReader sqlReader = null;
            SqlCommand command = new SqlCommand("SELECT * FROM [Table]", sqlConnection);
            try
            {
                sqlReader = await command.ExecuteReaderAsync();

                while (await sqlReader.ReadAsync())
                {
                    listBox1.Items.Add(Convert.ToString(sqlReader["id"]) + "     " + Convert.ToString(sqlReader["FIo"]) + "    " + Convert.ToString(sqlReader["Yearofbirth"]) + "    " + Convert.ToString(sqlReader["Number"]));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), ex.Source.ToString(), MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (sqlReader != null)
                {
                    sqlReader.Close();
                }
            }

        }
    }
}
