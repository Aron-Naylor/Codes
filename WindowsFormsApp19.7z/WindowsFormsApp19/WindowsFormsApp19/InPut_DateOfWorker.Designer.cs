﻿namespace WindowsFormsApp19
{
    partial class InPut_DateOfWorker
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Vv_Labl_Military = new System.Windows.Forms.Label();
            this.Vv_Text_Gender = new System.Windows.Forms.TextBox();
            this.Vv_Labl_INN = new System.Windows.Forms.Label();
            this.Vv_Text_TabNum = new System.Windows.Forms.TextBox();
            this.Vv_Labl_Snils = new System.Windows.Forms.Label();
            this.Vv_Text_DataWork = new System.Windows.Forms.TextBox();
            this.Vv_Labl_DataToWork = new System.Windows.Forms.Label();
            this.Vv_Text_Expiriance = new System.Windows.Forms.TextBox();
            this.Vv_Labl_Expirence = new System.Windows.Forms.Label();
            this.Vv_Text_Tel = new System.Windows.Forms.TextBox();
            this.Vv_Labl_Tel = new System.Windows.Forms.Label();
            this.Vv_Text_Addres = new System.Windows.Forms.TextBox();
            this.Vv_Labl_Addres = new System.Windows.Forms.Label();
            this.Vv_Text_DateOfBirth = new System.Windows.Forms.TextBox();
            this.Vv_Labl_DataOfBirth = new System.Windows.Forms.Label();
            this.Vv_Labl_Gender = new System.Windows.Forms.Label();
            this.Vv_Labl_Position = new System.Windows.Forms.Label();
            this.Vv_Text_Patronymic = new System.Windows.Forms.TextBox();
            this.Vv_Labl_Patronymic = new System.Windows.Forms.Label();
            this.Vv_Text_Name = new System.Windows.Forms.TextBox();
            this.Vv_Labl_Name = new System.Windows.Forms.Label();
            this.Vv_Text_LastName = new System.Windows.Forms.TextBox();
            this.Vv_Labl_LastName = new System.Windows.Forms.Label();
            this.Vv_Labl_Anket = new System.Windows.Forms.Label();
            this.Vv_Labl_TabNum = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Check_Military = new System.Windows.Forms.CheckBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(353, 218);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(149, 20);
            this.textBox2.TabIndex = 171;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(342, 192);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(160, 20);
            this.textBox1.TabIndex = 170;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.Check_Military);
            this.panel1.Controls.Add(this.Vv_Labl_Military);
            this.panel1.Location = new System.Drawing.Point(10, 192);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(253, 98);
            this.panel1.TabIndex = 168;
            // 
            // Vv_Labl_Military
            // 
            this.Vv_Labl_Military.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Vv_Labl_Military.Location = new System.Drawing.Point(-1, 5);
            this.Vv_Labl_Military.Name = "Vv_Labl_Military";
            this.Vv_Labl_Military.Size = new System.Drawing.Size(213, 23);
            this.Vv_Labl_Military.TabIndex = 128;
            this.Vv_Labl_Military.Text = "Сведения о военском учете:";
            this.Vv_Labl_Military.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Vv_Text_Gender
            // 
            this.Vv_Text_Gender.Location = new System.Drawing.Point(403, 81);
            this.Vv_Text_Gender.Name = "Vv_Text_Gender";
            this.Vv_Text_Gender.Size = new System.Drawing.Size(46, 20);
            this.Vv_Text_Gender.TabIndex = 167;
            // 
            // Vv_Labl_INN
            // 
            this.Vv_Labl_INN.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Vv_Labl_INN.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Vv_Labl_INN.Location = new System.Drawing.Point(287, 189);
            this.Vv_Labl_INN.Name = "Vv_Labl_INN";
            this.Vv_Labl_INN.Size = new System.Drawing.Size(49, 23);
            this.Vv_Labl_INN.TabIndex = 153;
            this.Vv_Labl_INN.Text = "ИНН:";
            this.Vv_Labl_INN.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Vv_Text_TabNum
            // 
            this.Vv_Text_TabNum.Location = new System.Drawing.Point(147, 10);
            this.Vv_Text_TabNum.Name = "Vv_Text_TabNum";
            this.Vv_Text_TabNum.Size = new System.Drawing.Size(49, 20);
            this.Vv_Text_TabNum.TabIndex = 165;
            // 
            // Vv_Labl_Snils
            // 
            this.Vv_Labl_Snils.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Vv_Labl_Snils.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Vv_Labl_Snils.Location = new System.Drawing.Point(287, 215);
            this.Vv_Labl_Snils.Name = "Vv_Labl_Snils";
            this.Vv_Labl_Snils.Size = new System.Drawing.Size(60, 23);
            this.Vv_Labl_Snils.TabIndex = 160;
            this.Vv_Labl_Snils.Text = "Снилс:";
            this.Vv_Labl_Snils.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Vv_Text_DataWork
            // 
            this.Vv_Text_DataWork.Location = new System.Drawing.Point(188, 141);
            this.Vv_Text_DataWork.Name = "Vv_Text_DataWork";
            this.Vv_Text_DataWork.Size = new System.Drawing.Size(93, 20);
            this.Vv_Text_DataWork.TabIndex = 164;
            // 
            // Vv_Labl_DataToWork
            // 
            this.Vv_Labl_DataToWork.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Vv_Labl_DataToWork.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Vv_Labl_DataToWork.Location = new System.Drawing.Point(10, 140);
            this.Vv_Labl_DataToWork.Name = "Vv_Labl_DataToWork";
            this.Vv_Labl_DataToWork.Size = new System.Drawing.Size(174, 23);
            this.Vv_Labl_DataToWork.TabIndex = 163;
            this.Vv_Labl_DataToWork.Text = "Дата приема на работу:";
            // 
            // Vv_Text_Expiriance
            // 
            this.Vv_Text_Expiriance.Location = new System.Drawing.Point(121, 167);
            this.Vv_Text_Expiriance.Name = "Vv_Text_Expiriance";
            this.Vv_Text_Expiriance.Size = new System.Drawing.Size(160, 20);
            this.Vv_Text_Expiriance.TabIndex = 162;
            // 
            // Vv_Labl_Expirence
            // 
            this.Vv_Labl_Expirence.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Vv_Labl_Expirence.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Vv_Labl_Expirence.Location = new System.Drawing.Point(10, 166);
            this.Vv_Labl_Expirence.Name = "Vv_Labl_Expirence";
            this.Vv_Labl_Expirence.Size = new System.Drawing.Size(105, 23);
            this.Vv_Labl_Expirence.TabIndex = 161;
            this.Vv_Labl_Expirence.Text = "Стаж работы:";
            // 
            // Vv_Text_Tel
            // 
            this.Vv_Text_Tel.Location = new System.Drawing.Point(369, 167);
            this.Vv_Text_Tel.Name = "Vv_Text_Tel";
            this.Vv_Text_Tel.Size = new System.Drawing.Size(133, 20);
            this.Vv_Text_Tel.TabIndex = 159;
            // 
            // Vv_Labl_Tel
            // 
            this.Vv_Labl_Tel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Vv_Labl_Tel.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Vv_Labl_Tel.Location = new System.Drawing.Point(287, 166);
            this.Vv_Labl_Tel.Name = "Vv_Labl_Tel";
            this.Vv_Labl_Tel.Size = new System.Drawing.Size(76, 23);
            this.Vv_Labl_Tel.TabIndex = 158;
            this.Vv_Labl_Tel.Text = "Телефон:";
            // 
            // Vv_Text_Addres
            // 
            this.Vv_Text_Addres.Location = new System.Drawing.Point(349, 141);
            this.Vv_Text_Addres.Name = "Vv_Text_Addres";
            this.Vv_Text_Addres.Size = new System.Drawing.Size(153, 20);
            this.Vv_Text_Addres.TabIndex = 157;
            // 
            // Vv_Labl_Addres
            // 
            this.Vv_Labl_Addres.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Vv_Labl_Addres.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Vv_Labl_Addres.Location = new System.Drawing.Point(287, 140);
            this.Vv_Labl_Addres.Name = "Vv_Labl_Addres";
            this.Vv_Labl_Addres.Size = new System.Drawing.Size(56, 23);
            this.Vv_Labl_Addres.TabIndex = 156;
            this.Vv_Labl_Addres.Text = "Адрес:";
            // 
            // Vv_Text_DateOfBirth
            // 
            this.Vv_Text_DateOfBirth.Location = new System.Drawing.Point(405, 115);
            this.Vv_Text_DateOfBirth.Name = "Vv_Text_DateOfBirth";
            this.Vv_Text_DateOfBirth.Size = new System.Drawing.Size(97, 20);
            this.Vv_Text_DateOfBirth.TabIndex = 155;
            // 
            // Vv_Labl_DataOfBirth
            // 
            this.Vv_Labl_DataOfBirth.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Vv_Labl_DataOfBirth.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Vv_Labl_DataOfBirth.Location = new System.Drawing.Point(287, 114);
            this.Vv_Labl_DataOfBirth.Name = "Vv_Labl_DataOfBirth";
            this.Vv_Labl_DataOfBirth.Size = new System.Drawing.Size(112, 23);
            this.Vv_Labl_DataOfBirth.TabIndex = 154;
            this.Vv_Labl_DataOfBirth.Text = "Дата рождения:";
            // 
            // Vv_Labl_Gender
            // 
            this.Vv_Labl_Gender.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Vv_Labl_Gender.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Vv_Labl_Gender.Location = new System.Drawing.Point(405, 55);
            this.Vv_Labl_Gender.Name = "Vv_Labl_Gender";
            this.Vv_Labl_Gender.Size = new System.Drawing.Size(44, 23);
            this.Vv_Labl_Gender.TabIndex = 152;
            this.Vv_Labl_Gender.Text = "Пол:";
            // 
            // Vv_Labl_Position
            // 
            this.Vv_Labl_Position.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Vv_Labl_Position.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Vv_Labl_Position.Location = new System.Drawing.Point(10, 114);
            this.Vv_Labl_Position.Name = "Vv_Labl_Position";
            this.Vv_Labl_Position.Size = new System.Drawing.Size(93, 23);
            this.Vv_Labl_Position.TabIndex = 151;
            this.Vv_Labl_Position.Text = "Должность:";
            // 
            // Vv_Text_Patronymic
            // 
            this.Vv_Text_Patronymic.Location = new System.Drawing.Point(271, 81);
            this.Vv_Text_Patronymic.Name = "Vv_Text_Patronymic";
            this.Vv_Text_Patronymic.Size = new System.Drawing.Size(126, 20);
            this.Vv_Text_Patronymic.TabIndex = 150;
            // 
            // Vv_Labl_Patronymic
            // 
            this.Vv_Labl_Patronymic.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Vv_Labl_Patronymic.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Vv_Labl_Patronymic.Location = new System.Drawing.Point(271, 55);
            this.Vv_Labl_Patronymic.Name = "Vv_Labl_Patronymic";
            this.Vv_Labl_Patronymic.Size = new System.Drawing.Size(79, 23);
            this.Vv_Labl_Patronymic.TabIndex = 149;
            this.Vv_Labl_Patronymic.Text = "Отчество:";
            // 
            // Vv_Text_Name
            // 
            this.Vv_Text_Name.Location = new System.Drawing.Point(147, 81);
            this.Vv_Text_Name.Name = "Vv_Text_Name";
            this.Vv_Text_Name.Size = new System.Drawing.Size(118, 20);
            this.Vv_Text_Name.TabIndex = 148;
            // 
            // Vv_Labl_Name
            // 
            this.Vv_Labl_Name.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Vv_Labl_Name.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Vv_Labl_Name.Location = new System.Drawing.Point(147, 55);
            this.Vv_Labl_Name.Name = "Vv_Labl_Name";
            this.Vv_Labl_Name.Size = new System.Drawing.Size(42, 23);
            this.Vv_Labl_Name.TabIndex = 147;
            this.Vv_Labl_Name.Text = "Имя:";
            // 
            // Vv_Text_LastName
            // 
            this.Vv_Text_LastName.Location = new System.Drawing.Point(13, 81);
            this.Vv_Text_LastName.Name = "Vv_Text_LastName";
            this.Vv_Text_LastName.Size = new System.Drawing.Size(128, 20);
            this.Vv_Text_LastName.TabIndex = 146;
            // 
            // Vv_Labl_LastName
            // 
            this.Vv_Labl_LastName.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Vv_Labl_LastName.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Vv_Labl_LastName.Location = new System.Drawing.Point(13, 55);
            this.Vv_Labl_LastName.Name = "Vv_Labl_LastName";
            this.Vv_Labl_LastName.Size = new System.Drawing.Size(83, 23);
            this.Vv_Labl_LastName.TabIndex = 145;
            this.Vv_Labl_LastName.Text = "Фамилия:";
            // 
            // Vv_Labl_Anket
            // 
            this.Vv_Labl_Anket.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Vv_Labl_Anket.Cursor = System.Windows.Forms.Cursors.Default;
            this.Vv_Labl_Anket.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Vv_Labl_Anket.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Vv_Labl_Anket.Location = new System.Drawing.Point(363, 7);
            this.Vv_Labl_Anket.Name = "Vv_Labl_Anket";
            this.Vv_Labl_Anket.Size = new System.Drawing.Size(142, 23);
            this.Vv_Labl_Anket.TabIndex = 144;
            this.Vv_Labl_Anket.Text = "Анкета сотрудника";
            this.Vv_Labl_Anket.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Vv_Labl_TabNum
            // 
            this.Vv_Labl_TabNum.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Vv_Labl_TabNum.Location = new System.Drawing.Point(10, 9);
            this.Vv_Labl_TabNum.Name = "Vv_Labl_TabNum";
            this.Vv_Labl_TabNum.Size = new System.Drawing.Size(142, 17);
            this.Vv_Labl_TabNum.TabIndex = 143;
            this.Vv_Labl_TabNum.Text = "Табельный номер";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(-9, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(535, 13);
            this.label1.TabIndex = 169;
            this.label1.Text = "_________________________________________________________________________________" +
    "_______";
            // 
            // Check_Military
            // 
            this.Check_Military.AutoSize = true;
            this.Check_Military.Location = new System.Drawing.Point(218, 11);
            this.Check_Military.Name = "Check_Military";
            this.Check_Military.Size = new System.Drawing.Size(15, 14);
            this.Check_Military.TabIndex = 129;
            this.Check_Military.UseVisualStyleBackColor = true;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(109, 115);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(172, 21);
            this.comboBox1.TabIndex = 172;
            // 
            // InPut_DateOfWorker
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(517, 297);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.Vv_Text_Gender);
            this.Controls.Add(this.Vv_Labl_INN);
            this.Controls.Add(this.Vv_Text_TabNum);
            this.Controls.Add(this.Vv_Labl_Snils);
            this.Controls.Add(this.Vv_Text_DataWork);
            this.Controls.Add(this.Vv_Labl_DataToWork);
            this.Controls.Add(this.Vv_Text_Expiriance);
            this.Controls.Add(this.Vv_Labl_Expirence);
            this.Controls.Add(this.Vv_Text_Tel);
            this.Controls.Add(this.Vv_Labl_Tel);
            this.Controls.Add(this.Vv_Text_Addres);
            this.Controls.Add(this.Vv_Labl_Addres);
            this.Controls.Add(this.Vv_Text_DateOfBirth);
            this.Controls.Add(this.Vv_Labl_DataOfBirth);
            this.Controls.Add(this.Vv_Labl_Gender);
            this.Controls.Add(this.Vv_Labl_Position);
            this.Controls.Add(this.Vv_Text_Patronymic);
            this.Controls.Add(this.Vv_Labl_Patronymic);
            this.Controls.Add(this.Vv_Text_Name);
            this.Controls.Add(this.Vv_Labl_Name);
            this.Controls.Add(this.Vv_Text_LastName);
            this.Controls.Add(this.Vv_Labl_LastName);
            this.Controls.Add(this.Vv_Labl_Anket);
            this.Controls.Add(this.Vv_Labl_TabNum);
            this.Controls.Add(this.label1);
            this.MaximizeBox = false;
            this.Name = "InPut_DateOfWorker";
            this.ShowIcon = false;
            this.Text = "InPut_DateOfWorker";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label Vv_Labl_Military;
        private System.Windows.Forms.TextBox Vv_Text_Gender;
        private System.Windows.Forms.Label Vv_Labl_INN;
        private System.Windows.Forms.TextBox Vv_Text_TabNum;
        private System.Windows.Forms.Label Vv_Labl_Snils;
        private System.Windows.Forms.TextBox Vv_Text_DataWork;
        private System.Windows.Forms.Label Vv_Labl_DataToWork;
        private System.Windows.Forms.TextBox Vv_Text_Expiriance;
        private System.Windows.Forms.Label Vv_Labl_Expirence;
        private System.Windows.Forms.TextBox Vv_Text_Tel;
        private System.Windows.Forms.Label Vv_Labl_Tel;
        private System.Windows.Forms.TextBox Vv_Text_Addres;
        private System.Windows.Forms.Label Vv_Labl_Addres;
        private System.Windows.Forms.TextBox Vv_Text_DateOfBirth;
        private System.Windows.Forms.Label Vv_Labl_DataOfBirth;
        private System.Windows.Forms.Label Vv_Labl_Gender;
        private System.Windows.Forms.Label Vv_Labl_Position;
        private System.Windows.Forms.TextBox Vv_Text_Patronymic;
        private System.Windows.Forms.Label Vv_Labl_Patronymic;
        private System.Windows.Forms.TextBox Vv_Text_Name;
        private System.Windows.Forms.Label Vv_Labl_Name;
        private System.Windows.Forms.TextBox Vv_Text_LastName;
        private System.Windows.Forms.Label Vv_Labl_LastName;
        private System.Windows.Forms.Label Vv_Labl_Anket;
        private System.Windows.Forms.Label Vv_Labl_TabNum;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox Check_Military;
        private System.Windows.Forms.ComboBox comboBox1;
    }
}