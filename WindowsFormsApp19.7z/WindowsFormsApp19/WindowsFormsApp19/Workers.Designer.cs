﻿namespace WindowsFormsApp19
{
    partial class spisokrab
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.ListOfPosts_button = new System.Windows.Forms.ToolStripMenuItem();
            this.OthersButton = new System.Windows.Forms.ToolStripMenuItem();
            this.найтиЗаписьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.отсортироватьОтАДоЯToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.отсортироватьПоПолуToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.отсортироватьПоЗадолжностямToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.button2 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.сформироватьОтчетToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(10, 27);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(215, 214);
            this.dataGridView1.TabIndex = 0;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(231, 45);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(95, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "Открыть";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(231, 103);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(95, 23);
            this.button3.TabIndex = 3;
            this.button3.Text = "Добавить";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ListOfPosts_button,
            this.OthersButton});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(335, 24);
            this.menuStrip1.TabIndex = 4;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // ListOfPosts_button
            // 
            this.ListOfPosts_button.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ListOfPosts_button.Name = "ListOfPosts_button";
            this.ListOfPosts_button.Size = new System.Drawing.Size(157, 20);
            this.ListOfPosts_button.Text = "Справочник должностей";
            // 
            // OthersButton
            // 
            this.OthersButton.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.найтиЗаписьToolStripMenuItem,
            this.отсортироватьОтАДоЯToolStripMenuItem,
            this.отсортироватьПоПолуToolStripMenuItem,
            this.отсортироватьПоЗадолжностямToolStripMenuItem,
            this.сформироватьОтчетToolStripMenuItem});
            this.OthersButton.Name = "OthersButton";
            this.OthersButton.Size = new System.Drawing.Size(107, 20);
            this.OthersButton.Text = "Дополнительно";
            // 
            // найтиЗаписьToolStripMenuItem
            // 
            this.найтиЗаписьToolStripMenuItem.Name = "найтиЗаписьToolStripMenuItem";
            this.найтиЗаписьToolStripMenuItem.Size = new System.Drawing.Size(257, 22);
            this.найтиЗаписьToolStripMenuItem.Text = "Найти запись";
            // 
            // отсортироватьОтАДоЯToolStripMenuItem
            // 
            this.отсортироватьОтАДоЯToolStripMenuItem.Name = "отсортироватьОтАДоЯToolStripMenuItem";
            this.отсортироватьОтАДоЯToolStripMenuItem.Size = new System.Drawing.Size(257, 22);
            this.отсортироватьОтАДоЯToolStripMenuItem.Text = "Отсортировать от А до Я";
            // 
            // отсортироватьПоПолуToolStripMenuItem
            // 
            this.отсортироватьПоПолуToolStripMenuItem.Name = "отсортироватьПоПолуToolStripMenuItem";
            this.отсортироватьПоПолуToolStripMenuItem.Size = new System.Drawing.Size(257, 22);
            this.отсортироватьПоПолуToolStripMenuItem.Text = "Отсортировать по гендеру";
            // 
            // отсортироватьПоЗадолжностямToolStripMenuItem
            // 
            this.отсортироватьПоЗадолжностямToolStripMenuItem.Name = "отсортироватьПоЗадолжностямToolStripMenuItem";
            this.отсортироватьПоЗадолжностямToolStripMenuItem.Size = new System.Drawing.Size(257, 22);
            this.отсортироватьПоЗадолжностямToolStripMenuItem.Text = "Отсортировать по задолжностям";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(231, 74);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(95, 23);
            this.button2.TabIndex = 5;
            this.button2.Text = "Редактировать";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(231, 132);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(95, 23);
            this.button4.TabIndex = 6;
            this.button4.Text = "Удалить";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // сформироватьОтчетToolStripMenuItem
            // 
            this.сформироватьОтчетToolStripMenuItem.Name = "сформироватьОтчетToolStripMenuItem";
            this.сформироватьОтчетToolStripMenuItem.Size = new System.Drawing.Size(257, 22);
            this.сформироватьОтчетToolStripMenuItem.Text = "Сформировать отчет";
            // 
            // spisokrab
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(335, 249);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "spisokrab";
            this.ShowIcon = false;
            this.Text = "Список работников";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem ListOfPosts_button;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.ToolStripMenuItem OthersButton;
        private System.Windows.Forms.ToolStripMenuItem найтиЗаписьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem отсортироватьОтАДоЯToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem отсортироватьПоПолуToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem отсортироватьПоЗадолжностямToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сформироватьОтчетToolStripMenuItem;
    }
}

